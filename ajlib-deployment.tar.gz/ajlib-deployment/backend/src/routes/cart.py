from flask import Blueprint, request, jsonify, session
from src.models.user import db
from src.models.cart import Cart, CartItem
from src.models.product import Product
import uuid

cart_bp = Blueprint('cart', __name__)

def get_or_create_cart(user_id=None, session_id=None):
    """الحصول على سلة التسوق أو إنشاء واحدة جديدة"""
    if user_id:
        cart = Cart.query.filter_by(user_id=user_id).first()
    else:
        if not session_id:
            session_id = str(uuid.uuid4())
        cart = Cart.query.filter_by(session_id=session_id).first()
    
    if not cart:
        cart = Cart(user_id=user_id, session_id=session_id)
        db.session.add(cart)
        db.session.commit()
    
    return cart

@cart_bp.route('/cart', methods=['GET'])
def get_cart():
    """الحصول على محتويات سلة التسوق"""
    try:
        user_id = request.args.get('user_id', type=int)
        session_id = request.args.get('session_id')
        
        if not user_id and not session_id:
            return jsonify({'success': False, 'error': 'مطلوب user_id أو session_id'}), 400
        
        cart = get_or_create_cart(user_id=user_id, session_id=session_id)
        
        return jsonify({
            'success': True,
            'cart': cart.to_dict()
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@cart_bp.route('/cart/add', methods=['POST'])
def add_to_cart():
    """إضافة منتج إلى سلة التسوق"""
    try:
        data = request.get_json()
        
        user_id = data.get('user_id')
        session_id = data.get('session_id')
        product_id = data.get('product_id')
        quantity = data.get('quantity', 1)
        size = data.get('size')
        color = data.get('color')
        
        if not product_id:
            return jsonify({'success': False, 'error': 'مطلوب product_id'}), 400
        
        if not user_id and not session_id:
            return jsonify({'success': False, 'error': 'مطلوب user_id أو session_id'}), 400
        
        # التحقق من وجود المنتج
        product = Product.query.filter_by(id=product_id, is_active=True).first()
        if not product:
            return jsonify({'success': False, 'error': 'المنتج غير موجود'}), 404
        
        # التحقق من توفر الكمية
        if product.stock_quantity < quantity:
            return jsonify({'success': False, 'error': 'الكمية المطلوبة غير متوفرة'}), 400
        
        # الحصول على السلة
        cart = get_or_create_cart(user_id=user_id, session_id=session_id)
        
        # البحث عن المنتج في السلة (نفس المنتج والحجم واللون)
        existing_item = CartItem.query.filter_by(
            cart_id=cart.id,
            product_id=product_id,
            size=size,
            color=color
        ).first()
        
        if existing_item:
            # تحديث الكمية
            new_quantity = existing_item.quantity + quantity
            if product.stock_quantity < new_quantity:
                return jsonify({'success': False, 'error': 'الكمية المطلوبة غير متوفرة'}), 400
            
            existing_item.quantity = new_quantity
        else:
            # إضافة عنصر جديد
            cart_item = CartItem(
                cart_id=cart.id,
                product_id=product_id,
                quantity=quantity,
                size=size,
                color=color,
                price=product.price
            )
            db.session.add(cart_item)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'تم إضافة المنتج إلى السلة',
            'cart': cart.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@cart_bp.route('/cart/update', methods=['PUT'])
def update_cart_item():
    """تحديث كمية منتج في السلة"""
    try:
        data = request.get_json()
        
        item_id = data.get('item_id')
        quantity = data.get('quantity')
        
        if not item_id or quantity is None:
            return jsonify({'success': False, 'error': 'مطلوب item_id و quantity'}), 400
        
        cart_item = CartItem.query.get(item_id)
        if not cart_item:
            return jsonify({'success': False, 'error': 'العنصر غير موجود'}), 404
        
        # التحقق من توفر الكمية
        if cart_item.product.stock_quantity < quantity:
            return jsonify({'success': False, 'error': 'الكمية المطلوبة غير متوفرة'}), 400
        
        if quantity <= 0:
            # حذف العنصر إذا كانت الكمية صفر أو أقل
            db.session.delete(cart_item)
        else:
            cart_item.quantity = quantity
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'تم تحديث السلة',
            'cart': cart_item.cart.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@cart_bp.route('/cart/remove/<int:item_id>', methods=['DELETE'])
def remove_from_cart(item_id):
    """حذف منتج من السلة"""
    try:
        cart_item = CartItem.query.get(item_id)
        if not cart_item:
            return jsonify({'success': False, 'error': 'العنصر غير موجود'}), 404
        
        cart = cart_item.cart
        db.session.delete(cart_item)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'تم حذف المنتج من السلة',
            'cart': cart.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@cart_bp.route('/cart/clear', methods=['DELETE'])
def clear_cart():
    """مسح جميع محتويات السلة"""
    try:
        user_id = request.args.get('user_id', type=int)
        session_id = request.args.get('session_id')
        
        if not user_id and not session_id:
            return jsonify({'success': False, 'error': 'مطلوب user_id أو session_id'}), 400
        
        if user_id:
            cart = Cart.query.filter_by(user_id=user_id).first()
        else:
            cart = Cart.query.filter_by(session_id=session_id).first()
        
        if not cart:
            return jsonify({'success': False, 'error': 'السلة غير موجودة'}), 404
        
        # حذف جميع العناصر
        CartItem.query.filter_by(cart_id=cart.id).delete()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'تم مسح السلة',
            'cart': cart.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

