from flask import Blueprint, request, jsonify
from src.models.user import db
from src.models.product import Product, Category, ProductImage
import json

product_bp = Blueprint('product', __name__)

@product_bp.route('/products', methods=['GET'])
def get_products():
    """الحصول على قائمة المنتجات مع إمكانية الفلترة والبحث"""
    try:
        # معاملات البحث والفلترة
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 12, type=int)
        search = request.args.get('search', '')
        category_id = request.args.get('category_id', type=int)
        min_price = request.args.get('min_price', type=float)
        max_price = request.args.get('max_price', type=float)
        sizes = request.args.get('sizes', '')
        colors = request.args.get('colors', '')
        sort_by = request.args.get('sort_by', 'created_at')
        sort_order = request.args.get('sort_order', 'desc')
        featured_only = request.args.get('featured', type=bool)
        
        # بناء الاستعلام
        query = Product.query.filter(Product.is_active == True)
        
        # البحث في الاسم والوصف
        if search:
            query = query.filter(
                db.or_(
                    Product.name.contains(search),
                    Product.description.contains(search)
                )
            )
        
        # فلترة حسب الفئة
        if category_id:
            query = query.filter(Product.category_id == category_id)
        
        # فلترة حسب السعر
        if min_price is not None:
            query = query.filter(Product.price >= min_price)
        if max_price is not None:
            query = query.filter(Product.price <= max_price)
        
        # فلترة حسب الأحجام
        if sizes:
            size_list = sizes.split(',')
            for size in size_list:
                query = query.filter(Product.sizes.contains(size.strip()))
        
        # فلترة حسب الألوان
        if colors:
            color_list = colors.split(',')
            for color in color_list:
                query = query.filter(Product.colors.contains(color.strip()))
        
        # فلترة المنتجات المميزة فقط
        if featured_only:
            query = query.filter(Product.is_featured == True)
        
        # الترتيب
        if sort_by == 'price':
            if sort_order == 'asc':
                query = query.order_by(Product.price.asc())
            else:
                query = query.order_by(Product.price.desc())
        elif sort_by == 'rating':
            query = query.order_by(Product.rating.desc())
        elif sort_by == 'name':
            if sort_order == 'asc':
                query = query.order_by(Product.name.asc())
            else:
                query = query.order_by(Product.name.desc())
        else:  # created_at
            if sort_order == 'asc':
                query = query.order_by(Product.created_at.asc())
            else:
                query = query.order_by(Product.created_at.desc())
        
        # التصفح
        products = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'success': True,
            'products': [product.to_dict() for product in products.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': products.total,
                'pages': products.pages,
                'has_next': products.has_next,
                'has_prev': products.has_prev
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@product_bp.route('/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    """الحصول على تفاصيل منتج محدد"""
    try:
        product = Product.query.filter_by(id=product_id, is_active=True).first()
        if not product:
            return jsonify({'success': False, 'error': 'المنتج غير موجود'}), 404
        
        return jsonify({
            'success': True,
            'product': product.to_dict()
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@product_bp.route('/categories', methods=['GET'])
def get_categories():
    """الحصول على قائمة الفئات"""
    try:
        categories = Category.query.all()
        return jsonify({
            'success': True,
            'categories': [category.to_dict() for category in categories]
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@product_bp.route('/products/featured', methods=['GET'])
def get_featured_products():
    """الحصول على المنتجات المميزة"""
    try:
        limit = request.args.get('limit', 8, type=int)
        
        products = Product.query.filter_by(
            is_active=True, 
            is_featured=True
        ).order_by(Product.created_at.desc()).limit(limit).all()
        
        return jsonify({
            'success': True,
            'products': [product.to_dict() for product in products]
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# Admin routes (يمكن إضافة middleware للتحقق من صلاحيات الإدارة)
@product_bp.route('/admin/products', methods=['POST'])
def create_product():
    """إنشاء منتج جديد (للإدارة)"""
    try:
        data = request.get_json()
        
        product = Product(
            name=data['name'],
            description=data.get('description'),
            price=data['price'],
            original_price=data.get('original_price'),
            stock_quantity=data.get('stock_quantity', 0),
            sku=data.get('sku'),
            sizes=json.dumps(data.get('sizes', [])),
            colors=json.dumps(data.get('colors', [])),
            features=json.dumps(data.get('features', [])),
            category_id=data.get('category_id'),
            is_featured=data.get('is_featured', False)
        )
        
        db.session.add(product)
        db.session.commit()
        
        # إضافة الصور إذا كانت موجودة
        if 'images' in data:
            for img_data in data['images']:
                image = ProductImage(
                    product_id=product.id,
                    image_url=img_data['url'],
                    alt_text=img_data.get('alt_text'),
                    is_primary=img_data.get('is_primary', False),
                    sort_order=img_data.get('sort_order', 0)
                )
                db.session.add(image)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'product': product.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

